/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  Zap, 
  ShieldCheck, 
  Star, 
  CheckCircle2, 
  Menu, 
  X, 
  ChevronRight,
  Car,
  Home,
  Factory,
  ArrowRight,
  Anchor,
  Medal,
  Users,
  ChevronDown,
  ChevronUp,
  Award,
  AlertTriangle,
  Sun,
  Search,
  Thermometer
} from 'lucide-react';
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix for Leaflet default icon issues
const customIcon = new L.Icon({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
});

const MapController = ({ center, zoom }: { center: [number, number], zoom: number }) => {
  const map = useMap();
  useEffect(() => {
    map.flyTo(center, zoom, {
      duration: 1.5
    });
  }, [center, zoom, map]);
  return null;
};

const SERVICES = [
  {
    icon: <Zap className="w-8 h-8 text-brand-green" />,
    title: "Sikringsskap",
    intro: <span>Gamle sikringsskap kan være <strong>brannfarlige</strong> – vi oppgraderer <strong>raskt og trygt</strong>.</span>,
    offer: "Moderne automatsikringer og full dokumentasjon i Boligmappa.",
    cta: "Få pris på sikringsskap"
  },
  {
    icon: <Car className="w-8 h-8 text-brand-green" />,
    title: "Elbillader",
    intro: <span>Vi installerer <strong>elbillader</strong> hjemme hos deg – ferdig på <strong>én dag</strong>.</span>,
    offer: "Fast pris, godkjent installasjon og klar til bruk på dagen.",
    cta: "Bestill elbillader"
  },
  {
    icon: <AlertTriangle className="w-8 h-8 text-brand-green" />,
    title: "Akutt hjelp",
    intro: <span>Har strømmen gått eller lukter det svidd? <strong>Vi rykker ut</strong>.</span>,
    offer: "Rask feilsøking og utrykning i hele Bergen.",
    cta: "Ring vakttelefon"
  },
  {
    icon: <Sun className="w-8 h-8 text-brand-green" />,
    title: "Energieffektivisering",
    intro: <span>Spar penger og miljøet med <strong>smarte løsninger</strong>.</span>,
    offer: "Vi hjelper deg med ENOVA-støtte og energisparende tiltak.",
    cta: "Se sparemuligheter"
  },
  {
    icon: <Search className="w-8 h-8 text-brand-green" />,
    title: "El-kontroll",
    intro: <span>Sikre boligen din med en <strong>grundig sjekk</strong> av det elektriske anlegget.</span>,
    offer: "Forsikringsgodkjent kontroll som gir trygghet og rabatter.",
    cta: "Bestill kontroll"
  },
  {
    icon: <Thermometer className="w-8 h-8 text-brand-green" />,
    title: "Varmepumpe",
    intro: <span>Stabil varme og <strong>lavere strømregning</strong> hele året.</span>,
    offer: "Autorisert montering av markedsledende varmepumper.",
    cta: "Få tilbud på pumpe"
  }
];

const TESTIMONIALS = [
  {
    name: "Eivind Nessen Tangen",
    rating: 5,
    text: <span>Meget <strong>imøtekommende og fleksibel</strong> elektriker. Oppdaget feil på kobling i sikringsskap som tidligere elektriker hadde montert. Dette ble korrigert på en <strong>utmerket måte</strong>.</span>,
    date: "Local Guide"
  },
  {
    name: "Hans Jørgen Tuft",
    rating: 5,
    text: <span>De utfører til <strong>avtalt tid og pris</strong>, gjør en <strong>ryddig jobb</strong>, og det bare fungerer når de er ferdig. <strong>Anbefales!</strong></span>,
    date: "Saga Energy AS"
  },
  {
    name: "Maya",
    rating: 5,
    text: <span><strong>God på pris og effektiv</strong>. Veldig fornøyd med jobben som ble gjort.</span>,
    date: "Local Guide"
  },
  {
    name: "Nye muligheter",
    rating: 5,
    text: <span>Stiller <strong>kjapt opp</strong> og gjør en god jobb med godt humør og gode priser. En <strong>trygg elektriker i Bergen</strong>.</span>,
    date: "Local Guide"
  },
  {
    name: "Jacob Sæter",
    rating: 5,
    text: <span><strong>Ekstremt dyktige fagfolk</strong> som vet hva de holder på med. Anbefales på det sterkeste.</span>,
    date: "Kunde"
  },
  {
    name: "Marita Jacobsen",
    rating: 5,
    text: <span>Responsivitet, <strong>punktlighet, kvalitet og profesjonalitet</strong>. Her får du virkelig valuta for pengene.</span>,
    date: "Local Guide"
  }
];

const LOCATIONS = [
  {
    id: 1,
    name: "Hovedkontor",
    address: "Leirvikflaten 5, Godvik",
    lat: 60.3702,
    lng: 5.2014,
    type: "office"
  },
  {
    id: 2,
    name: "Bergen Sentrum",
    address: "Torgallmenningen",
    lat: 60.3913,
    lng: 5.3247,
    type: "service"
  },
  {
    id: 3,
    name: "Åsane",
    address: "Åsane Senter",
    lat: 60.4684,
    lng: 5.3262,
    type: "service"
  },
  {
    id: 4,
    name: "Fana / Lagunen",
    address: "Laguneveien",
    lat: 60.3014,
    lng: 5.3332,
    type: "service"
  },
  {
    id: 5,
    name: "Askøy / Kleppestø",
    address: "Kleppestø Senter",
    lat: 60.4075,
    lng: 5.2300,
    type: "service"
  },
  {
    id: 6,
    name: "Sotra / Straume",
    address: "Sartor Senter",
    lat: 60.3544,
    lng: 5.1275,
    type: "service"
  }
];

const Logo = ({ className = "", light = false }: { className?: string; light?: boolean }) => (
  <div className={`flex items-center gap-3 ${className}`}>
    <div className="relative flex-shrink-0">
      <svg width="40" height="40" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M50 10C35 10 23 22 23 37C23 46 29 54 36 59C40 62 42 66 42 70V75C42 78 44 80 47 80H53C56 80 58 78 58 75V70C58 66 60 62 64 59C71 54 77 46 77 37C77 22 65 10 50 10Z" stroke={light ? "white" : "#00E676"} strokeWidth="4" strokeLinecap="round"/>
        <path d="M42 85H58" stroke={light ? "white" : "#00E676"} strokeWidth="4" strokeLinecap="round"/>
        <path d="M45 90H55" stroke={light ? "white" : "#00E676"} strokeWidth="4" strokeLinecap="round"/>
        <path d="M50 25V35M40 37H30M70 37H60M43 45L37 51M57 45L63 51" stroke={light ? "white" : "#00E676"} strokeWidth="3" strokeLinecap="round"/>
        <circle cx="50" cy="37" r="8" stroke={light ? "white" : "#00E676"} strokeWidth="2" />
        <path d="M50 33L50 41M46 37L54 37" stroke={light ? "white" : "#00E676"} strokeWidth="2" />
      </svg>
    </div>
    <div className="flex flex-col leading-none">
      <div className={`font-display font-black text-2xl md:text-3xl tracking-tighter uppercase ${light ? "text-white" : "text-brand-blue"}`}>
        Kjell Hansen
      </div>
      <div className="flex items-center gap-1">
        <div className="h-4 px-1.5 bg-brand-green rounded-sm flex items-center">
          <span className="text-[10px] font-black uppercase text-brand-dark tracking-tighter">Bærekraftig</span>
        </div>
        <div className={`font-display font-black text-2xl md:text-3xl tracking-tighter uppercase ${light ? "text-white" : "text-brand-blue"}`}>
          Elektro
        </div>
      </div>
    </div>
  </div>
);

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [mapCenter, setMapCenter] = useState<[number, number]>([60.3800, 5.2500]);
  const [mapZoom, setMapZoom] = useState(11);
  const [activeLocId, setActiveLocId] = useState<number | null>(null);
  const [isChargerFormOpen, setIsChargerFormOpen] = useState(false);

  const [isMapVisible, setIsMapVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsMapVisible(true);
          observer.disconnect();
        }
      },
      { rootMargin: '200px' }
    );
    
    const target = document.getElementById('lokasjoner');
    if (target) observer.observe(target);
    
    return () => observer.disconnect();
  }, []);

  const handleLocClick = (loc: typeof LOCATIONS[0]) => {
    setIsMapVisible(true); // Ensure map is loaded if clicked from outside
    setMapCenter([loc.lat, loc.lng]);
    setMapZoom(14);
    setActiveLocId(loc.id);
    
    // Smooth scroll to map if on mobile
    if (window.innerWidth < 768) {
      const mapElem = document.getElementById('lokasjoner');
      mapElem?.scrollIntoView({ behavior: 'smooth' });
    }
  };
  const [chargerForm, setChargerForm] = useState({
    name: "",
    email: "",
    phone: ""
  });

  const handleChargerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Charger order:", chargerForm);
    alert("Takk for din bestilling! Vi kontakter deg snart.");
    setChargerForm({ name: "", email: "", phone: "" });
  };
  const [formSubject, setFormSubject] = useState("");
  const [selectedCountryCode, setSelectedCountryCode] = useState("+47");

  const scrollToContact = (subject?: string) => {
    if (subject) setFormSubject(subject);
    const element = document.getElementById('kontakt');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const faqs = [
    {
      question: "Tilbyr dere gratis befaring?",
      answer: <span>Ja, vi tilbyr <strong>gratis befaring</strong> for alle større prosjekter i Bergen.</span>
    },
    {
      question: "Hvilke garantier gir dere på utført arbeid?",
      answer: <span>Vi gir <strong>5 års reklamasjonsrett</strong> til private. All dokumentasjon leveres digitalt i <strong>Boligmappa</strong>.</span>
    },
    {
      question: "Hvor raskt kan dere rykke ut ved akutte problemer?",
      answer: <span>Vi prioriterer <strong>utrykning samme dag</strong> ved kritiske feil og fare for varmgang.</span>
    },
    {
      question: "Kan dere hjelpe med søknad om Enova-støtte?",
      answer: <span>Ja, vi utfører tiltak som kvalifiserer for <strong>Enova-støtte</strong> og leverer nødvendig dokumentasjon.</span>
    },
    {
      question: "Hva er deres priser for mindre elektriker-oppdrag?",
      answer: <span>Vi har <strong>konkurransedyktige priser</strong> og gir ofte prisestimat direkte over telefon eller e-post.</span>
    }
  ];

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 overflow-x-hidden">
      {/* Navigation */}
      <nav 
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled ? 'bg-white/95 backdrop-blur-md shadow-md py-2' : 'bg-transparent py-4 text-white'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          <button 
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity"
            aria-label="Rull til toppen"
          >
            <Logo light={!scrolled} />
          </button>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8 font-medium">
            <a href="#tjenester" className="hover:text-brand-green transition-colors">Tjenester</a>
            <a href="#om-oss" className="hover:text-brand-green transition-colors">Om oss</a>
            <a href="#anmeldelser" className="hover:text-brand-green transition-colors">Anmeldelser</a>
            <a href="#karriere" className="hover:text-brand-green transition-colors">Karriere</a>
            <a href="#lokasjoner" className="hover:text-brand-green transition-colors">Kart</a>
            <button 
              onClick={() => scrollToContact("Generell kontakt")}
              className="hover:text-brand-green transition-colors"
            >
              Kontakt
            </button>
            <a 
              href="tel:55154030" 
              className={`flex items-center gap-2 px-5 py-2.5 rounded-full transition-all hover:scale-105 active:scale-95 ${
                scrolled ? 'bg-brand-blue text-white shadow-lg shadow-brand-blue/20' : 'bg-white text-brand-blue'
              }`}
            >
              <Phone size={18} />
              <span>55 15 40 30</span>
            </a>
          </div>

          {/* Mobile Menu Toggle */}
          <button 
            className="md:hidden p-2 rounded-md transition-colors"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>

        {/* Mobile Menu Overlay */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="absolute top-full left-0 right-0 bg-white shadow-2xl overflow-hidden md:hidden text-slate-900 border-t border-slate-100"
            >
              <div className="p-6 flex flex-col gap-2">
                <a 
                  href="#tjenester" 
                  onClick={() => setIsMenuOpen(false)} 
                  className="flex items-center justify-between py-4 text-xl font-bold border-b border-slate-50 active:bg-slate-50 px-2 rounded-lg transition-colors"
                >
                  <span>Tjenester</span>
                  <ChevronDown className="w-5 h-5 -rotate-90 text-slate-300" />
                </a>
                <a 
                  href="#om-oss" 
                  onClick={() => setIsMenuOpen(false)} 
                  className="flex items-center justify-between py-4 text-xl font-bold border-b border-slate-50 active:bg-slate-50 px-2 rounded-lg transition-colors"
                >
                  <span>Om oss</span>
                  <ChevronDown className="w-5 h-5 -rotate-90 text-slate-300" />
                </a>
                <a 
                  href="#anmeldelser" 
                  onClick={() => setIsMenuOpen(false)} 
                  className="flex items-center justify-between py-4 text-xl font-bold border-b border-slate-50 active:bg-slate-50 px-2 rounded-lg transition-colors"
                >
                  <span>Anmeldelser</span>
                  <ChevronDown className="w-5 h-5 -rotate-90 text-slate-300" />
                </a>
                <a 
                  href="#karriere" 
                  onClick={() => setIsMenuOpen(false)} 
                  className="flex items-center justify-between py-4 text-xl font-bold border-b border-slate-50 active:bg-slate-50 px-2 rounded-lg transition-colors"
                >
                  <span>Karriere</span>
                  <ChevronDown className="w-5 h-5 -rotate-90 text-slate-300" />
                </a>
                <a 
                  href="#lokasjoner" 
                  onClick={() => setIsMenuOpen(false)} 
                  className="flex items-center justify-between py-4 text-xl font-bold border-b border-slate-50 active:bg-slate-50 px-2 rounded-lg transition-colors"
                >
                  <span>Kart</span>
                  <ChevronDown className="w-5 h-5 -rotate-90 text-slate-300" />
                </a>

                <div className="grid grid-cols-1 gap-4 mt-6">
                  <button 
                    onClick={() => {
                      setIsMenuOpen(false);
                      scrollToContact("Mobilmeny CTA");
                    }}
                    className="w-full bg-brand-green text-brand-dark py-5 rounded-2xl font-bold text-lg flex items-center justify-center gap-2 shadow-lg shadow-brand-green/20"
                  >
                    <Mail size={22} />
                    Få gratis befaring
                  </button>
                  
                  <a 
                    href="tel:55154030" 
                    className="w-full bg-slate-100 text-brand-blue py-5 rounded-2xl font-bold text-lg flex items-center justify-center gap-2"
                  >
                    <Phone size={22} />
                    Ring 55 15 40 30
                  </a>
                </div>

                <div className="mt-8 pt-6 border-t border-slate-100 flex flex-col items-center text-center">
                  <p className="text-slate-400 text-sm font-medium mb-2">Vakttelefon Bergen</p>
                  <p className="text-brand-blue font-bold text-lg underline">55 15 40 30</p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center pt-20 overflow-hidden bg-brand-dark text-white">
        {/* Background Image with Overlay */}
        <div className="absolute inset-0 z-0">
          {/* IMAGE PLACEHOLDER: Elektriker i arbeid */}
          <img 
            src="https://images.unsplash.com/photo-1621905251918-48416bd8575a?q=60&w=1600&auto=format&fit=crop" 
            alt="Elektriker i arbeid i Bergen" 
            className="w-full h-full object-cover opacity-40"
            referrerPolicy="no-referrer"
            loading="eager"
            decoding="async"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-brand-dark via-brand-dark/80 to-transparent"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-2xl"
          >
            <div className="inline-flex items-center gap-2 bg-brand-green text-brand-dark px-4 py-2 rounded-full mb-6 font-bold tracking-wide uppercase text-sm animate-pulse">
              <Clock className="w-4 h-4" />
              <span>Svar innen 1 time</span>
            </div>
            
            <h1 className="text-5xl md:text-8xl font-display font-black leading-[1.1] mb-4">
              Elektriker i <span className="text-brand-green">Bergen</span>
            </h1>
            
            <div className="text-xl md:text-4xl font-display font-bold text-white mb-6 tracking-tight">
              <strong>Har du strømproblem?</strong> Vi fikser det <strong>i dag</strong>.
            </div>

            <p className="text-lg md:text-xl text-slate-300 mb-10 leading-relaxed max-w-lg">
              Fra elbillader til nytt sikringsskap – <strong>vi fikser det.</strong>
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <button 
                onClick={() => scrollToContact("Gratis befaring")}
                className="bg-brand-green text-brand-dark px-10 py-5 rounded-xl font-bold text-xl flex items-center justify-center gap-2 hover:bg-white transition-all transform hover:-translate-y-1 shadow-2xl shadow-brand-green/20 hover:shadow-none"
              >
                Få gratis befaring
                <ArrowRight size={20} />
              </button>
              <a 
                href="tel:55154030" 
                className="bg-white text-brand-blue px-10 py-5 rounded-xl font-bold text-xl flex items-center justify-center gap-2 hover:bg-slate-50 transition-all shadow-xl"
              >
                <Phone size={20} />
                Ring 55 15 40 30
              </a>
            </div>
            
            <p className="text-brand-green font-bold flex items-center gap-2">
              <CheckCircle2 size={18} />
              Vi dekker Bergen, Askøy, Sotra og Os.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Fastprispakke Section - Updated to match website */}
      <section className="py-12 md:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row gap-12 items-start">
            <div className="flex-1">
              <h2 className="text-4xl font-display font-black text-brand-blue mb-6 tracking-tight">FASTPRISPAKKE</h2>
              <p className="text-xl text-slate-700 mb-6 leading-relaxed">
                <strong>Zaptec Go</strong> er norskprodusert, ledende og bygget for tøffe forhold.
              </p>
              <div className="text-2xl font-bold text-slate-900 mb-8">
                Installert: <span className="text-brand-blue">kr 15 990,–</span>
              </div>
              
              <button 
                onClick={() => scrollToContact("Mer info om elbillader")}
                className="bg-brand-blue text-white px-8 py-3 rounded-lg font-bold mb-12 hover:bg-brand-dark transition-all"
              >
                Les mer om elbillader i Bergen
              </button>

              {/* Bestill Ladeboks Form */}
              <div className="w-full max-w-sm rounded-lg overflow-hidden shadow-2xl border border-slate-100 mb-12">
                <button 
                  onClick={() => setIsChargerFormOpen(!isChargerFormOpen)}
                  className="w-full bg-[#32CD32] p-4 flex items-center justify-between text-white font-black transition-colors hover:bg-[#2eb82e]"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-5 h-5 flex items-center justify-center border-2 border-white rounded-sm">
                      {isChargerFormOpen ? <span className="text-xl leading-none">-</span> : <span className="text-xl leading-none">+</span>}
                    </div>
                    <span className="uppercase tracking-wider">Bestill ladeboks</span>
                  </div>
                  <ChevronDown className={`transition-transform duration-300 ${isChargerFormOpen ? 'rotate-180' : ''}`} size={20} />
                </button>
                
                <AnimatePresence>
                  {isChargerFormOpen && (
                    <motion.div 
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                      className="overflow-hidden bg-white border-x border-b border-slate-100"
                    >
                      <div className="p-8">
                        <form onSubmit={handleChargerSubmit} className="space-y-6">
                          <div>
                            <label className="block text-sm font-bold mb-2 text-slate-900">
                              Navn <span className="text-red-500">*</span>
                            </label>
                            <input 
                              type="text" 
                              required
                              className="w-full p-2.5 border border-slate-300 rounded focus:ring-2 focus:ring-brand-green outline-none"
                              value={chargerForm.name}
                              onChange={(e) => setChargerForm({...chargerForm, name: e.target.value})}
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-bold mb-2 text-slate-900">
                              E-post
                            </label>
                            <input 
                              type="email" 
                              className="w-full p-2.5 border border-slate-300 rounded focus:ring-2 focus:ring-brand-green outline-none"
                              value={chargerForm.email}
                              onChange={(e) => setChargerForm({...chargerForm, email: e.target.value})}
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-bold mb-2 text-slate-900">
                              Telefon <span className="text-red-500">*</span>
                            </label>
                            <div className="flex gap-2">
                              <div className="flex items-center gap-1 px-2 border border-slate-300 rounded bg-slate-50 text-sm">
                                <img src="https://flagcdn.com/w20/no.png" alt="NO" className="w-5" />
                                <ChevronDown size={14} />
                              </div>
                              <input 
                                type="tel" 
                                required
                                className="flex-1 p-2.5 border border-slate-300 rounded focus:ring-2 focus:ring-brand-green outline-none"
                                placeholder="40 61 23 45"
                                value={chargerForm.phone}
                                onChange={(e) => setChargerForm({...chargerForm, phone: e.target.value})}
                              />
                            </div>
                          </div>
                          <button 
                            type="submit"
                            className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-6 py-2.5 rounded font-bold transition-colors"
                          >
                            Send
                          </button>
                        </form>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>

            <div className="flex-1 relative">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border-4 border-white">
                <img 
                  src="https://images.unsplash.com/photo-1593941707882-a5bba14938c7?q=60&w=1200&auto=format&fit=crop" 
                  alt="Zaptec Go Elbillader Best i Test" 
                  className="w-full h-auto"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                  decoding="async"
                />
                <div className="absolute top-1/2 right-12 w-28 h-28 bg-[#F5DE00] rounded-sm transform rotate-3 flex flex-col items-center justify-center p-3 text-center border-2 border-black/10">
                  <div className="flex items-center gap-1 mb-1">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d4/Norges_Automobil-Forbund_logo.svg/800px-Norges_Automobil-Forbund_logo.svg.png" alt="NAF" className="h-6" />
                  </div>
                  <div className="font-bold text-[10px] leading-tight text-brand-dark uppercase">Best i test</div>
                  <div className="text-2xl font-black text-brand-dark">2022</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-16 bg-white border-y border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-brand-green font-bold uppercase tracking-widest text-sm mb-4">Godkjenninger & Trygghet</h2>
            <h3 className="text-3xl font-display font-bold text-brand-blue">Din garanti for kvalitet</h3>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="flex flex-col items-center text-center">
              <ShieldCheck className="w-12 h-12 text-brand-green mb-4" />
              <div className="font-bold text-lg leading-tight">Autorisert elektriker</div>
              <div className="text-sm text-slate-500">DSB-godkjent</div>
            </div>
            <div className="flex flex-col items-center text-center">
              <Award className="w-12 h-12 text-brand-green mb-4" />
              <div className="font-bold text-lg leading-tight">10+ års erfaring</div>
              <div className="text-sm text-slate-500">I hele Bergen</div>
            </div>
            <div className="flex flex-col items-center text-center">
              <Clock className="w-12 h-12 text-brand-green mb-4" />
              <div className="font-bold text-lg leading-tight">Rask responstid</div>
              <div className="text-sm text-slate-500">Svar på 1 time</div>
            </div>
            <div className="flex flex-col items-center text-center">
              <MapPin className="w-12 h-12 text-brand-green mb-4" />
              <div className="font-bold text-lg leading-tight">Bergen & Omegn</div>
              <div className="text-sm text-slate-500">Fast oppmøtepris</div>
            </div>
          </div>
        </div>
      </section>

      {/* Emergency Call Section */}
      <section className="bg-brand-green py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-4 text-brand-dark">
              <div className="bg-white p-3 rounded-full animate-bounce">
                <Phone size={32} />
              </div>
              <div>
                <h3 className="text-2xl font-black">Trenger du elektriker i dag?</h3>
                <p className="font-bold opacity-80">Vi svarer raskt – Ring oss nå!</p>
              </div>
            </div>
            <a 
              href="tel:55154030" 
              className="bg-brand-blue text-white text-3xl font-black px-12 py-6 rounded-2xl shadow-2xl hover:scale-105 transition-transform"
            >
              55 15 40 30
            </a>
          </div>
        </div>
      </section>

      {/* Reference Images Section */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mb-12">
          <h2 className="text-3xl md:text-5xl font-display font-bold text-brand-blue mb-4">
            Se hva vi har gjort for kunder i Bergen
          </h2>
          <p className="text-slate-600 font-medium">Bilder fra våre prosjekter.</p>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="group relative overflow-hidden rounded-[32px] shadow-xl aspect-square">
            {/* IMAGE PLACEHOLDER: Sikringsskap før/etter */}
            <img 
              src="https://images.unsplash.com/photo-1621905251189-08b45d6a269e?q=60&w=800&auto=format&fit=crop" 
              alt="Nytt sikringsskap i Bergen" 
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              referrerPolicy="no-referrer"
              loading="lazy"
              decoding="async"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-end p-8 flex-col justify-end">
              <p className="text-white font-bold text-xl">Oppgradert sikringsskap</p>
              <p className="text-brand-green text-sm font-bold">Askøy – Mars 2024</p>
            </div>
          </div>
          
          <div className="group relative overflow-hidden rounded-[32px] shadow-xl aspect-square">
            {/* IMAGE PLACEHOLDER: Elbillader installasjon */}
            <img 
              src="https://images.unsplash.com/photo-1593941707882-a5bba14938c7?q=60&w=800&auto=format&fit=crop" 
              alt="Installert Zaptec elbillader" 
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              referrerPolicy="no-referrer"
              loading="lazy"
              decoding="async"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-end p-8 flex-col justify-end">
              <p className="text-white font-bold text-xl">Elbillader i garasje</p>
              <p className="text-brand-green text-sm font-bold">Landaas – April 2024</p>
            </div>
          </div>

          <div className="group relative overflow-hidden rounded-[32px] shadow-xl aspect-square">
            {/* IMAGE PLACEHOLDER: Belysning prosjekt */}
            <img 
              src="https://images.unsplash.com/photo-1565814329452-e1efa11c5b89?q=60&w=800&auto=format&fit=crop" 
              alt="Moderne belysning i stue" 
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              referrerPolicy="no-referrer"
              loading="lazy"
              decoding="async"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-end p-8 flex-col justify-end">
              <p className="text-white font-bold text-xl">Moderne downlights</p>
              <p className="text-brand-green text-sm font-bold">Søreide – Mai 2024</p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="tjenester" className="py-16 md:py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-brand-green font-bold uppercase tracking-widest text-sm mb-4">Våre Tjenester</h2>
          <h3 className="text-3xl md:text-5xl font-display font-bold leading-tight text-brand-blue">
            Markedsledende innen <span className="text-brand-green">bærekraftig</span> elektro
          </h3>
          <div className="w-20 h-1.5 bg-brand-green mx-auto mt-6 rounded-full"></div>
        </div>
 
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {SERVICES.map((service, index) => (
            <motion.div 
              key={index}
              whileHover={{ y: -10 }}
              className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 hover:shadow-2xl transition-all group flex flex-col h-full"
            >
              <div className="bg-slate-50 w-16 h-16 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-brand-green group-hover:text-brand-dark transition-colors duration-300">
                {service.icon}
              </div>
              <h4 className="text-2xl font-bold mb-4">{service.title}</h4>
              <div className="flex-1 space-y-4 mb-6">
                <p className="text-slate-600 font-medium text-sm leading-relaxed italic border-l-2 border-brand-green pl-3">
                  {service.intro}
                </p>
                <p className="text-slate-500 text-sm leading-relaxed">
                  {service.offer}
                </p>
              </div>
              <button 
                onClick={() => scrollToContact(`Tjeneste: ${service.title}`)}
                className="flex items-center justify-between gap-2 font-bold text-brand-blue hover:text-brand-green transition-colors mt-auto pt-6 border-t border-slate-50 w-full text-left"
              >
                <span>{service.cta}</span>
                <ChevronRight size={18} />
              </button>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Om oss Section - Merged with USPs */}
      <section id="om-oss" className="bg-brand-blue text-white py-16 md:py-24 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-16 items-center mb-20">
            <div>
              <h2 className="text-brand-green font-bold uppercase tracking-widest text-sm mb-4">Om oss</h2>
              <h3 className="text-3xl md:text-5xl font-display font-bold mb-8">
                Bergens stolthet <span className="text-brand-green italic">siden 1940</span>
              </h3>
              <p className="text-brand-blue-100 text-lg mb-8 leading-relaxed">
                I over 80 år har vi levert trygghet til Bergens hjem. Som autoriserte fagfolk garanterer vi kvalitet, <strong>fast pris</strong> og dokumentasjon i Boligmappa.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                <div className="flex items-center gap-3 bg-white/5 p-4 rounded-xl border border-white/10">
                  <ShieldCheck className="text-brand-green" />
                  <span className="font-bold text-sm">DSB-godkjent</span>
                </div>
                <div className="flex items-center gap-3 bg-white/5 p-4 rounded-xl border border-white/10">
                  <Medal className="text-brand-green" />
                  <span className="font-bold text-sm">Mesterbedrift</span>
                </div>
              </div>
              <button 
                onClick={() => scrollToContact("Befaring Om Oss")}
                className="bg-brand-green text-brand-dark px-10 py-5 rounded-xl font-bold text-lg flex items-center gap-2 hover:bg-white transition-all shadow-xl"
              >
                Start ditt prosjekt
                <ArrowRight size={20} />
              </button>
            </div>
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1621905251189-08b45d6a269e?q=60&w=1200&auto=format&fit=crop" 
                alt="Kjell Hansen Elektro Team" 
                className="rounded-[40px] shadow-2xl border-8 border-white/10"
                referrerPolicy="no-referrer"
                loading="lazy"
                decoding="async"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white/5 p-8 rounded-3xl border border-white/10">
              <Clock className="text-brand-green mb-4" size={32} />
              <h4 className="text-xl font-bold mb-2">Rask respons</h4>
              <p className="text-brand-blue-100 text-sm">Vi rykker ut samme dag ved akutte behov i hele Bergen.</p>
            </div>
            <div className="bg-white/5 p-8 rounded-3xl border border-white/10">
              <Zap className="text-brand-green mb-4" size={32} />
              <h4 className="text-xl font-bold mb-2">Fastpris-garanti</h4>
              <p className="text-brand-blue-100 text-sm">Du får alltid en bindende pris før vi starter arbeidet.</p>
            </div>
            <div className="bg-white/5 p-8 rounded-3xl border border-white/10">
              <Award className="text-brand-green mb-4" size={32} />
              <h4 className="text-xl font-bold mb-2">80+ års erfaring</h4>
              <p className="text-brand-blue-100 text-sm">Ingen kjenner Bergens elektriske anlegg bedre enn oss.</p>
            </div>
          </div>
        </div>
      </section>
      {/* Oppussing Section */}
      <section className="py-16 md:py-24 bg-brand-blue text-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center gap-12 md:gap-16">
          <div className="flex-1">
            <h2 className="text-brand-green font-bold uppercase tracking-widest text-sm mb-4">Vi hjelper deg å lykkes</h2>
            <h3 className="text-3xl md:text-5xl font-display font-bold mb-8 italic">Skal du pusse opp?</h3>
            <p className="text-brand-blue-100 text-lg mb-8 leading-relaxed">
              Bred erfaring med <strong>oppussing</strong>. Du får en <strong>dedikert saksbehandler</strong> som din personlige fagrådgiver.
            </p>
            <ul className="space-y-4 mb-10">
              <li className="flex items-center gap-3">
                <CheckCircle2 className="text-brand-green" size={20} />
                <span>Moderne og forskriftsmessige løsninger</span>
              </li>
              <li className="flex items-center gap-3">
                <CheckCircle2 className="text-brand-green" size={20} />
                <span>Totalansvar – vi koordinerer alt det elektriske</span>
              </li>
            </ul>
            <button 
              onClick={() => scrollToContact("Befaring: Oppussingsprosjekt")}
              className="inline-flex items-center gap-2 bg-brand-green text-brand-dark px-8 py-4 rounded-xl font-bold hover:bg-white transition-all transform hover:scale-105"
            >
              Få gratis befaring
              <ArrowRight size={20} />
            </button>
          </div>
          <div className="flex-1 relative">
            <div className="relative z-10 rounded-[40px] overflow-hidden border-8 border-white shadow-2xl">
              <img 
                src="https://images.unsplash.com/photo-1556912172-45b7abe8b7e1?q=60&w=1200&auto=format&fit=crop" 
                alt="Moderne interiør" 
                className="w-full h-full object-cover"
                loading="lazy"
                decoding="async"
              />
            </div>
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-brand-green/20 rounded-full blur-3xl"></div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="anmeldelser" className="py-16 md:py-24 bg-slate-50 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 md:mb-16 gap-6">
            <div>
              <h2 className="text-brand-blue font-bold uppercase tracking-widest text-sm mb-4">Referanser</h2>
              <h3 className="text-3xl md:text-5xl font-display font-bold">Hva våre kunder sier</h3>
            </div>
            <div className="flex items-center gap-4 bg-white p-4 rounded-2xl shadow-sm border border-slate-100 italic">
              <div className="flex text-brand-green italic">
                {[...Array(5)].map((_, i) => <Star key={i} size={20} fill="currentColor" />)}
              </div>
              <span className="font-bold text-base md:text-lg">4.6 i snitt (29 vurderinger)</span>
            </div>
          </div>
 
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {TESTIMONIALS.map((t, i) => (
              <div key={i} className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 relative">
                <div className="flex gap-1 text-brand-green mb-4">
                  {[...Array(t.rating)].map((_, i) => <Star key={i} size={16} fill="currentColor" />)}
                </div>
                <p className="text-slate-700 italic text-lg mb-6 leading-relaxed">"{t.text}"</p>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-bold">{t.name}</div>
                    <div className="text-sm text-slate-500">{t.date}</div>
                  </div>
              <div className="text-slate-100 absolute bottom-6 right-8 opacity-20">
                    <Zap size={40} className="fill-current" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Career Section */}
      <section id="karriere" className="py-16 md:py-24 bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row items-center gap-12 md:gap-16">
            <div className="flex-1">
              <h2 className="text-brand-green font-bold uppercase tracking-widest text-sm mb-4">Jobbe hos oss</h2>
              <h3 className="text-3xl md:text-5xl font-display font-bold mb-8 italic text-brand-blue">Bli en del av Bergens stolthet</h3>
              <p className="text-slate-600 text-lg mb-8 leading-relaxed">
                Bli en del av Bergens mest tradisjonsrike elektrofirma. Vi bygger <strong>karrierer og fagfolk</strong>.
              </p>
              
              <div className="grid sm:grid-cols-2 gap-8 mb-10">
                <div className="flex gap-4">
                  <div className="text-brand-blue bg-slate-50 p-3 rounded-2xl h-fit">
                    <Zap size={24} />
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">Akkordarbeid</h4>
                    <p className="text-sm text-slate-500">Påvirke egen lønn i et av byens mest <strong>tradisjonsrike</strong> firmaer.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="text-brand-blue bg-slate-50 p-3 rounded-2xl h-fit">
                    <Star size={24} />
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">Karriereløp</h4>
                    <p className="text-sm text-slate-500">Fra <strong>montør til bas</strong>, prosjektleder eller teamleder. Vi bygger folk.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="text-brand-blue bg-slate-50 p-3 rounded-2xl h-fit">
                    <CheckCircle2 size={24} />
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">Mentorprogram</h4>
                    <p className="text-sm text-slate-500"><strong>Personlig oppfølging</strong> og kontinuerlig faglig utvikling.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="text-brand-blue bg-slate-50 p-3 rounded-2xl h-fit">
                    <ShieldCheck size={24} />
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">Trygge goder</h4>
                    <p className="text-sm text-slate-500">Fast <strong>helseforsikring</strong>, pensjon og sosiale goder.</p>
                  </div>
                </div>
              </div>
 
              <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100 mb-10">
                <h4 className="font-bold mb-3 text-brand-blue uppercase text-xs tracking-widest">Prestigefylte Prosjekter</h4>
                <div className="flex flex-wrap gap-3">
                  {["Hotell Hordaheimen", "Bane NOR", "Gamlehaugen veksthus", "Oasen senter"].map((p, i) => (
                    <span key={i} className="bg-white px-3 py-1.5 rounded-lg text-sm font-medium text-slate-600 shadow-sm border border-slate-100">
                      {p}
                    </span>
                  ))}
                </div>
              </div>
 
              <div className="flex flex-col sm:flex-row gap-4">
                <a href="mailto:signe@kjell-hansen.no" className="bg-brand-green text-brand-dark px-8 py-4 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-brand-blue hover:text-white transition-all">
                  Send CV til Signe
                  <Mail size={18} />
                </a>
                <a href="tel:93016680" className="bg-slate-50 border-2 border-slate-200 text-brand-blue px-8 py-4 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-white transition-all">
                  Ring Kjetil (930 16 680)
                </a>
              </div>
            </div>
            <div className="flex-1 relative">
              <div className="relative rounded-[40px] overflow-hidden shadow-2xl border-8 border-white">
                <img 
                  src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=60&w=1200&auto=format&fit=crop" 
                  alt="Team i arbeid" 
                  className="w-full aspect-square object-cover"
                  loading="lazy"
                  decoding="async"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-brand-blue/60 to-transparent"></div>
                <div className="absolute bottom-8 left-8 right-8 text-white">
                  <div className="text-3xl font-display font-bold mb-2">Sammen skaper vi verdier</div>
                  <p className="text-white/80">Bli med i et arbeidsmiljø som heier på deg.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Ideal Customer / Qualification Section */}
      <section className="py-16 md:py-24 bg-white border-y border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-brand-green font-bold uppercase tracking-widest text-sm mb-4">Er vi riktig match?</h2>
            <h3 className="text-3xl md:text-5xl font-display font-bold text-brand-blue">Hvem vi hjelper <span className="text-brand-green italic">best</span></h3>
            <p className="mt-6 text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
              Vi er ikke en "altmuligmann". Vi er spesialister på trygge, varige elektriske anlegg for kunder som verdsetter kvalitet.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 md:gap-12">
            {/* Best suited for */}
            <div className="bg-slate-50 p-8 md:p-12 rounded-[40px] border border-slate-100">
              <div className="flex items-center gap-3 text-brand-blue mb-8">
                <div className="bg-brand-green/20 p-3 rounded-2xl">
                  <CheckCircle2 className="text-brand-green" size={32} />
                </div>
                <h4 className="text-2xl font-bold italic">Vi er best for deg som:</h4>
              </div>
              <ul className="space-y-6">
                <li className="flex gap-4">
                  <div className="w-6 h-6 rounded-full bg-brand-green/20 flex items-center justify-center shrink-0 mt-1">
                    <CheckCircle2 size={16} className="text-brand-green" />
                  </div>
                  <div>
                    <p className="font-bold text-brand-blue mb-1">Verdsetter kvalitet og sikkerhet</p>
                    <p className="text-slate-500 text-sm">Du vil ha en installasjon som varer i tiår, ikke bare til neste år.</p>
                  </div>
                </li>
                <li className="flex gap-4">
                  <div className="w-6 h-6 rounded-full bg-brand-green/20 flex items-center justify-center shrink-0 mt-1">
                    <CheckCircle2 size={16} className="text-brand-green" />
                  </div>
                  <div>
                    <p className="font-bold text-brand-blue mb-1">Krever full dokumentasjon</p>
                    <p className="text-slate-500 text-sm">Du vil ha alt rett inn i Boligmappa for full sporbarhet ved salg av bolig.</p>
                  </div>
                </li>
                <li className="flex gap-4">
                  <div className="w-6 h-6 rounded-full bg-brand-green/20 flex items-center justify-center shrink-0 mt-1">
                    <CheckCircle2 size={16} className="text-brand-green" />
                  </div>
                  <div>
                    <p className="font-bold text-brand-blue mb-1">Ønsker en ryddig totalentreprenør</p>
                    <p className="text-slate-500 text-sm">Best egnet for mellomstore til store prosjekter, oppussing og ladesystemer.</p>
                  </div>
                </li>
              </ul>
            </div>

            {/* Not for / Qualifying */}
            <div className="bg-brand-blue/5 p-8 md:p-12 rounded-[40px] border border-brand-blue/10">
              <div className="flex items-center gap-3 text-brand-blue mb-8">
                <div className="bg-slate-200 p-3 rounded-2xl text-slate-400">
                  <X className="" size={32} />
                </div>
                <h4 className="text-2xl font-bold italic">Vi er kanskje ikke for deg som:</h4>
              </div>
              <ul className="space-y-6">
                <li className="flex gap-4">
                  <div className="w-6 h-6 rounded-full bg-slate-200 flex items-center justify-center shrink-0 mt-1">
                    <X size={16} className="text-slate-400" />
                  </div>
                  <div>
                    <p className="font-bold text-brand-blue mb-1">Kun ser etter laveste anbud</p>
                    <p className="text-slate-500 text-sm">Vi konkurrerer ikke på pris mot useriøse aktører. Kvalitet har en korrekt pris.</p>
                  </div>
                </li>
                <li className="flex gap-4">
                  <div className="w-6 h-6 rounded-full bg-slate-200 flex items-center justify-center shrink-0 mt-1">
                    <X size={16} className="text-slate-400" />
                  </div>
                  <div>
                    <p className="font-bold text-brand-blue mb-1">Ønsker "svart arbeid" eller snarveier</p>
                    <p className="text-slate-500 text-sm">Vi følger forskriftene slavisk. Ingen snarveier, ingen unntak.</p>
                  </div>
                </li>
                <li className="flex gap-4">
                  <div className="w-6 h-6 rounded-full bg-slate-200 flex items-center justify-center shrink-0 mt-1">
                    <X size={16} className="text-slate-400" />
                  </div>
                  <div>
                    <p className="font-bold text-brand-blue mb-1">Har svært små enkeltoppdrag (småfiks)</p>
                    <p className="text-slate-500 text-sm">Vi prioriterer våre faste kunder og større prosjekter for å sikre kapasitet.</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="mt-12 p-8 bg-brand-blue text-white rounded-3xl text-center">
            <p className="text-lg font-medium italic">
              "Vi bygger ikke bare elektriske anlegg, vi bygger trygghet. Hvis du er opptatt av kvalitet og en ryddig prosess, er vi en perfekt match."
            </p>
          </div>
        </div>
      </section>

      {/* FAQ & Support Section */}
      <section className="py-16 md:py-24 bg-slate-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-brand-green font-bold uppercase tracking-widest text-sm mb-4">Ofte stilte spørsmål</h2>
            <h3 className="text-3xl md:text-4xl font-display font-bold leading-tight">Noe du lurer på?</h3>
          </div>
 
          <div className="space-y-4 mb-16">
            {faqs.map((faq, index) => (
              <div 
                key={index} 
                className={`bg-white rounded-2xl border transition-all duration-300 ${openFaq === index ? 'border-brand-green ring-1 ring-brand-green shadow-lg' : 'border-slate-100'}`}
              >
                <button
                  type="button"
                  onClick={() => setOpenFaq(openFaq === index ? null : index)}
                  className="w-full flex items-center justify-between p-6 text-left focus:outline-none"
                >
                  <span className="text-lg font-bold text-brand-blue pr-8">{faq.question}</span>
                  <div className={`p-2 rounded-full transition-colors ${openFaq === index ? 'bg-brand-green text-brand-dark' : 'bg-slate-100 text-slate-400'}`}>
                    {openFaq === index ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                  </div>
                </button>
                
                <AnimatePresence>
                  {openFaq === index && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.2 }}
                      className="overflow-hidden"
                    >
                      <div className="px-6 pb-6 text-slate-600 text-sm md:text-base leading-relaxed border-t border-slate-50 pt-4">
                        {faq.answer}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </div>

          <div className="bg-brand-blue rounded-[32px] p-8 md:p-12 text-center text-white shadow-2xl relative overflow-hidden">
            <h4 className="text-2xl md:text-3xl font-display font-bold mb-6">Fant du ikke svaret?</h4>
            <p className="text-slate-300 mb-8 max-w-lg mx-auto leading-relaxed">Vi rykker ut i hele Bergen. Send oss en melding for raskt svar!</p>
            <button 
              onClick={() => scrollToContact("Spørsmål FAQ")}
              className="inline-flex items-center gap-3 bg-brand-green text-brand-dark px-10 py-4 rounded-xl font-bold hover:bg-white transition-all shadow-xl shadow-brand-green/20"
            >
              Kontakt oss nå
              <ArrowRight size={20} />
            </button>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-16 md:py-24 bg-white relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 md:mb-20">
            <h2 className="text-brand-green font-bold uppercase tracking-widest text-sm mb-4">Enkel prosess</h2>
            <h3 className="text-3xl md:text-5xl font-display font-bold text-brand-blue">Veien til en <span className="italic">trygg installasjon</span></h3>
          </div>
 
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 relative">
            {/* Connection Line */}
            <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-0.5 bg-slate-100 -translate-y-12 z-0"></div>
            
            {[
              { step: "01", title: "Ekspertvalidering", desc: <span>Vi kartlegger behov og gir deg en <strong>personlig fagrådgiver</strong> fra dag én.</span> },
              { step: "02", title: "Garantert Pris", desc: <span>Du mottar et bindende tilbud med <strong>fastpris på kroner og øre</strong>.</span> },
              { step: "03", title: "Ryddig Utførelse", desc: <span>Vi rydder etter oss og sørger for at alt er <strong>proft levert</strong> til rett tid.</span> },
              { step: "04", title: "Trygg Boligmappa", desc: <span>Alt arbeid dokumenteres med <strong>full sporbarhet</strong> i din digitale Boligmappa.</span> }
            ].map((p, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                viewport={{ once: true }}
                className="relative z-10 text-center"
              >
                <div className="w-16 h-16 rounded-2xl bg-slate-50 text-brand-green flex items-center justify-center text-2xl font-black mx-auto mb-6 shadow-sm border border-slate-100">
                  {p.step}
                </div>
                <h4 className="text-xl font-bold mb-3">{p.title}</h4>
                <p className="text-slate-500 text-sm leading-relaxed">{p.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section id="lokasjoner" className="py-20 bg-slate-50 border-y border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-brand-green font-bold uppercase tracking-widest text-sm mb-4">Her finner du oss</h2>
            <h3 className="text-3xl md:text-5xl font-display font-bold">Vårt nedslagsfelt i Bergen</h3>
            <p className="mt-4 text-slate-600 max-w-2xl mx-auto font-medium">
              Vi dekker hele Bergen og omegn.
            </p>
          </div>
 
          <div className="bg-white rounded-[40px] shadow-2xl p-4 overflow-hidden border border-slate-100">
            <div className="h-[500px] rounded-[32px] overflow-hidden z-0 bg-slate-100 flex items-center justify-center">
              {isMapVisible ? (
                <MapContainer 
                  center={mapCenter} 
                  zoom={mapZoom} 
                  scrollWheelZoom={false} 
                  style={{ height: '100%', width: '100%' }}
                >
                  <TileLayer
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  />
                  <MapController center={mapCenter} zoom={mapZoom} />
                  {LOCATIONS.map((loc) => (
                    <Marker 
                      key={loc.id} 
                      position={[loc.lat, loc.lng]} 
                      icon={customIcon}
                    >
                      <Popup>
                        <div className="p-1">
                          <h4 className="font-bold text-brand-blue m-0">{loc.name}</h4>
                          <p className="text-sm text-slate-600 m-1 mb-2">{loc.address}</p>
                          <div className="flex gap-2">
                            <a 
                              href={`https://www.google.com/maps/dir/?api=1&destination=${loc.lat},${loc.lng}`} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="bg-brand-blue text-white text-[10px] px-2 py-1 rounded font-bold hover:bg-brand-green hover:text-brand-dark transition-colors"
                            >
                              Veibeskrivelse
                            </a>
                          </div>
                        </div>
                      </Popup>
                    </Marker>
                  ))}
                </MapContainer>
              ) : (
                <div className="flex flex-col items-center gap-4 text-slate-400">
                  <Zap size={48} className="animate-pulse" />
                  <p className="font-medium">Laster kart...</p>
                </div>
              )}
            </div>
          </div>
 
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mt-12">
            {LOCATIONS.map((loc) => (
              <button 
                key={loc.id} 
                onClick={() => handleLocClick(loc)}
                className={`bg-white p-4 rounded-2xl border transition-all duration-300 text-center group transform hover:-translate-y-1 hover:shadow-xl ${
                  activeLocId === loc.id 
                  ? 'border-brand-green ring-1 ring-brand-green bg-slate-50' 
                  : 'border-slate-100 hover:border-brand-green/30 hover:bg-slate-50'
                }`}
              >
                <div className={`w-10 h-10 rounded-xl mx-auto mb-3 flex items-center justify-center transition-transform group-hover:scale-110 ${
                  loc.type === 'office' 
                  ? 'bg-brand-green text-brand-dark' 
                  : 'bg-brand-blue text-white'
                }`}>
                  {loc.type === 'office' ? <ShieldCheck size={20} /> : <Zap size={20} />}
                </div>
                <div className="font-bold text-sm text-brand-blue group-hover:text-brand-green transition-colors">{loc.name}</div>
                <div className="text-[10px] text-slate-500 mt-1 uppercase tracking-wider">{loc.type === 'office' ? 'Hovedkontor' : 'Serviceområde'}</div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="kontakt" className="py-16 md:py-24 bg-brand-blue">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-brand-dark rounded-[48px] overflow-hidden flex flex-col lg:flex-row shadow-3xl">
            {/* Form Side */}
            <div className="flex-1 p-6 sm:p-8 md:p-16 text-white text-left">
              <h2 className="text-3xl md:text-5xl font-display font-bold mb-6 italic text-left">Få gratis befaring</h2>
              <p className="text-slate-400 text-base md:text-lg mb-10 text-left">
                Vi hjelper deg med trygge, dokumenterte installasjonsløsninger. 
                <span className="block mt-2 text-brand-green font-bold italic">Full Boligmappa-dokumentasjon og 5 års garanti inkludert som standard.</span>
              </p>
              
              <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
                <div className="bg-white/5 p-6 rounded-3xl border border-white/10 space-y-6">
                  <h4 className="text-lg font-bold text-brand-green italic">Personinformasjon</h4>
                  <div className="grid sm:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-semibold text-slate-300">Navn *</label>
                      <input type="text" className="w-full bg-brand-dark border border-slate-700 rounded-xl px-4 py-3 focus:ring-2 focus:ring-brand-green focus:outline-none transition-all placeholder:text-slate-600" placeholder="Ditt fullstendige navn" required />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-semibold text-slate-300">Telefon *</label>
                      <div className="flex gap-2 min-w-0">
                        <div className="relative shrink-0">
                          <select 
                            value={selectedCountryCode}
                            onChange={(e) => setSelectedCountryCode(e.target.value)}
                            className="bg-brand-dark border border-slate-700 rounded-xl px-3 py-3 focus:ring-2 focus:ring-brand-green focus:outline-none transition-all text-white appearance-none pr-8 cursor-pointer text-sm"
                          >
                            <option value="+47">🇳🇴 +47</option>
                            <option value="+46">🇸🇪 +46</option>
                            <option value="+45">🇩🇰 +45</option>
                            <option value="+358">🇫🇮 +358</option>
                            <option value="+44">🇬🇧 +44</option>
                            <option value="+1">🇺🇸 +1</option>
                          </select>
                          <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-500" />
                        </div>
                        <input type="tel" className="flex-1 min-w-0 bg-brand-dark border border-slate-700 rounded-xl px-4 py-3 focus:ring-2 focus:ring-brand-green focus:outline-none transition-all placeholder:text-slate-600" placeholder="Ditt nummer" required />
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-slate-300">E-post *</label>
                    <input type="email" className="w-full bg-brand-dark border border-slate-700 rounded-xl px-4 py-3 focus:ring-2 focus:ring-brand-green focus:outline-none transition-all placeholder:text-slate-600" placeholder="Din e-post adresse" required />
                  </div>
                </div>

                <div className="bg-white/5 p-6 rounded-3xl border border-white/10 space-y-6">
                  <h4 className="text-lg font-bold text-brand-green italic">Prosjektdetaljer</h4>
                  <div className="grid sm:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-semibold text-slate-300">Adresse for oppdrag *</label>
                      <input type="text" className="w-full bg-brand-dark border border-slate-700 rounded-xl px-4 py-3 focus:ring-2 focus:ring-brand-green focus:outline-none transition-all placeholder:text-slate-600" placeholder="Gateadresse, postnummer, sted" required />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-semibold text-slate-300">Emne *</label>
                      <input 
                        type="text" 
                        value={formSubject}
                        onChange={(e) => setFormSubject(e.target.value)}
                        className="w-full bg-brand-dark border border-slate-700 rounded-xl px-4 py-3 focus:ring-2 focus:ring-brand-green focus:outline-none transition-all placeholder:text-slate-600" 
                        placeholder="Hva gjelder det?" 
                        required 
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-slate-300">Melding *</label>
                    <textarea rows={4} className="w-full bg-brand-dark border border-slate-700 rounded-xl px-4 py-3 focus:ring-2 focus:ring-brand-green focus:outline-none transition-all placeholder:text-slate-600 text-white" placeholder="Beskriv oppdraget så godt du kan..." required></textarea>
                  </div>
                </div>

                <div className="flex items-center gap-3 text-brand-blue-100 text-sm">
                  <div className="w-5 h-5 rounded border border-brand-green flex items-center justify-center shrink-0">
                    <CheckCircle2 size={12} className="text-brand-green" />
                  </div>
                  <p>Jeg godtar at Kjell Hansen Elektro AS behandler mine personopplysninger for å kunne kontakte meg angående dette oppdraget.</p>
                </div>

                <button type="submit" className="w-full bg-brand-green text-brand-dark py-5 rounded-xl font-bold text-xl hover:bg-white transition-all shadow-xl hover:scale-[1.02] active:scale-[0.98]">
                  Send henvendelse nå
                </button>
              </form>
            </div>

            {/* Info Side */}
            <div className="lg:w-[450px] bg-brand-blue p-8 md:p-16 text-white flex flex-col justify-between">
              <div>
                <h3 className="text-2xl font-bold mb-10 pb-4 border-b border-white/10 uppercase tracking-wider">Kontaktinfo</h3>
                <div className="space-y-8">
                  <div className="flex gap-4 items-start">
                    <div className="bg-white/10 p-3 rounded-xl"><Phone size={24} className="text-brand-green" /></div>
                    <div>
                      <div className="text-sm text-white/60 font-medium">Ring oss på</div>
                      <a href="tel:55154030" className="text-xl font-bold hover:text-brand-green">55 15 40 30</a>
                    </div>
                  </div>
                  <div className="flex gap-4 items-start">
                    <div className="bg-white/10 p-3 rounded-xl"><Mail size={24} className="text-brand-green" /></div>
                    <div>
                      <div className="text-sm text-white/60 font-medium">Send e-post</div>
                      <a href="mailto:post@kjell-hansen.no" className="text-xl font-bold hover:text-brand-green">post@kjell-hansen.no</a>
                    </div>
                  </div>
                  <div className="flex gap-4 items-start">
                    <div className="bg-white/10 p-3 rounded-xl"><MapPin size={24} className="text-brand-green" /></div>
                    <div>
                      <div className="text-sm text-white/60 font-medium">Adresse</div>
                      <div className="text-lg font-bold">Leirvikflaten 5, 5179 Godvik</div>
                    </div>
                  </div>
                  <div className="flex gap-4 items-start">
                    <div className="bg-white/10 p-3 rounded-xl"><Clock size={24} className="text-brand-green" /></div>
                    <div>
                      <div className="text-sm text-white/60 font-medium">Åpningstider</div>
                      <div className="text-lg font-bold italic">Man–Fre: 07:30–16:00</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-12 opacity-80 pt-8 border-t border-white/10">
                <p className="text-sm italic leading-relaxed">
                  "Vi i Kjell Hansen Elektro er stolte over å levere bærekraftige løsninger som varer. Kontakt oss i dag for en grønnere og tryggere hverdag."
                </p>
                <div className="mt-4 font-bold text-brand-green">— Kjell Hansen, Daglig leder</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer Branding */}
      <footer className="bg-brand-dark text-white pt-16 md:pt-20 pb-10 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
            <div className="space-y-6">
              <Logo light />
              <p className="text-slate-400 leading-relaxed">
                Profesjonell elektro og <strong>trygghet siden 1940</strong>. Bærekraftige løsninger for private og næring.
              </p>
              <div className="flex gap-4">
                <div className="bg-white/5 p-2 rounded-lg hover:text-brand-green transition-colors cursor-pointer">
                  <Zap size={20} />
                </div>
                <div className="bg-white/5 p-2 rounded-lg hover:text-brand-green transition-colors cursor-pointer">
                  <ShieldCheck size={20} />
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="font-bold text-xl mb-6 italic">Tjenester</h4>
              <ul className="space-y-4 text-slate-400">
                <li><a href="#" className="hover:text-brand-green transition-colors font-medium">Sikringsskap</a></li>
                <li><a href="#" className="hover:text-brand-green transition-colors font-medium">Elbillader</a></li>
                <li><a href="#" className="hover:text-brand-green transition-colors font-medium">Energieffektivisering</a></li>
                <li><a href="#" className="hover:text-brand-green transition-colors font-medium">Boliginstallasjon</a></li>
                <li><a href="#" className="hover:text-brand-green transition-colors font-medium">Varmepumper</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-xl mb-6 italic">Kontakt oss</h4>
              <ul className="space-y-4 text-slate-400">
                <li className="flex items-start gap-3">
                  <MapPin className="text-brand-green shrink-0 mt-1" size={20} />
                  <span>Leirvikflaten 5,<br />5179 Godvik</span>
                </li>
                <li className="flex items-center gap-3">
                  <Phone className="text-brand-green" size={20} />
                  <a href="tel:55154030" className="hover:text-brand-green transition-colors">55 15 40 30</a>
                </li>
                <li className="flex items-center gap-3">
                  <Mail className="text-brand-green" size={20} />
                  <a href="mailto:post@kjell-hansen.no" className="hover:text-brand-green transition-colors">post@kjell-hansen.no</a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-xl mb-6 italic">Åpningstider</h4>
              <ul className="space-y-4 text-slate-400">
                <li className="flex items-center justify-between">
                  <span>Mandag - Fredag</span>
                  <span className="text-white font-medium">07:30 - 16:00</span>
                </li>
                <li className="flex items-center justify-between">
                  <span>Lørdag - Søndag</span>
                  <span className="text-brand-green font-bold italic underline">Etter avtale</span>
                </li>
                <li className="pt-4">
                  <div className="bg-brand-green/10 p-4 rounded-2xl border border-brand-green/20">
                    <p className="text-xs font-bold uppercase tracking-widest text-brand-green mb-1">Døgnvakt?</p>
                    <p className="text-sm text-slate-300 leading-snug">Vi har beredskapsavtaler for våre faste næringskunder.</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>

          <div className="pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6 text-sm text-slate-500">
            <p>© {new Date().getFullYear()} Kjell Hansen Elektro AS. Alle rettigheter reservert. Org.nr: 981 336 945</p>
            <div className="flex gap-8">
              <a href="#" className="hover:text-white transition-colors">Personvern</a>
              <a href="#" className="hover:text-white transition-colors">Brukervilkår</a>
              <a href="#" className="hover:text-white transition-colors">Cookies</a>
            </div>
          </div>
        </div>
      </footer>

      {/* Sticky Mobile/Desktop Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 z-[60] p-4 md:hidden">
        <div className="bg-brand-blue/95 backdrop-blur-md rounded-2xl shadow-2xl p-2 flex gap-2 border border-white/10">
          <a href="tel:55154030" className="flex-1 bg-white text-brand-blue py-3 rounded-xl font-bold flex items-center justify-center gap-2">
            <Phone size={18} />
            Ring oss
          </a>
          <button 
            onClick={() => scrollToContact("Forespørsel via mobilmeny")}
            className="flex-[2] bg-brand-green text-brand-dark py-3 rounded-xl font-bold flex items-center justify-center gap-2"
          >
            <Mail size={18} />
            Få befaring
          </button>
        </div>
      </div>

      <motion.div 
        initial={{ opacity: 0, x: -50 }}
        animate={{ opacity: scrolled ? 1 : 0, x: scrolled ? 0 : -50 }}
        className="fixed bottom-8 left-8 z-[60] hidden md:block"
      >
        <button 
          onClick={() => scrollToContact("Gratis befaringforespørsel")}
          className="flex items-center gap-3 bg-white text-brand-blue p-2 pr-6 rounded-2xl font-bold shadow-2xl hover:bg-brand-green hover:text-brand-dark transition-all group border border-slate-200"
        >
          <div className="w-12 h-12 bg-brand-blue text-brand-green rounded-xl flex items-center justify-center group-hover:bg-brand-dark transition-colors">
            <CheckCircle2 size={24} />
          </div>
          <div className="flex flex-col text-left">
            <span className="text-[10px] uppercase tracking-widest text-slate-400 leading-none mb-1">Uforpliktende</span>
            <span className="leading-none">Få gratis befaring</span>
          </div>
        </button>
      </motion.div>
      
    </div>
  );
}
